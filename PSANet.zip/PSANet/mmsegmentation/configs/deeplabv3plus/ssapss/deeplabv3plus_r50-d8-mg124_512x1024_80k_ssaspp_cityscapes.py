_base_ = '../deeplabv3plus_r50-d8_512x1024_80k_cityscapes.py'
model = dict(
    backbone=dict(
        multi_grid=(1, 2, 4)),
    decode_head=dict(
        dilations=(1, 6, 6, 6)))
